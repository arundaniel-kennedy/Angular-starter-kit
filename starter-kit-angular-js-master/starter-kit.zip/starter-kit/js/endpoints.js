var BASE_URL = "http://localhost:8000/";
var endpoints = {
    TASK: BASE_URL + "task/:id/"
}