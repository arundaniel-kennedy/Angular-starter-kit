angular.module('starter', [
    'ui.bootstrap',
    'ngRoute',
    'ngResource',
    'ngAnimate'
]);